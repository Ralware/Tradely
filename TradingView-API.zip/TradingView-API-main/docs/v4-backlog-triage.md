# V4 backlog triage — 3 October 2026

Baseline: `da67081` / published `4.0.0-beta.1`. Snapshot: **96 open issues and 8 open PRs**.

Follow-up: #334 was merged on 3 October 2026. The focused fixes are included in the beta.2 release candidate. Reliability tools from #330 were subsequently ported without its stale version/README changes; the completed two-hour result is recorded in [reliability evidence](v4-reliability.md). The issue table below is refreshed through beta.5/stabilization; dated verification sections retain their original evidence.

This is an issue-by-issue disposition, not a claim that 96 bugs were reproduced or fixed.
Evidence comes from issue descriptions, current source/tests and the existing [coverage matrix](v4-coverage.md).
“Covered by code” is weaker than a targeted regression or live reproduction. “Needs” means keep open.
No issues/legacy PRs were closed, and no contributor comments were sent by this pass.

## Initial beta.1 findings (historical)

1. **Authentication gap:** PR #330 is still open. Its `/chart/` default and non-3xx redirect guard are absent from beta.1. This change ports only that focused fix with its regression test, not its old release/version text.
2. **Concrete missing feature:** #225 country/sector search filters implemented in this change, with deterministic query coverage and a public live endpoint probe.
3. **Do not close private/paid/long-running reports from general smoke results.** In particular #89, #188, #236, #311 and #24 remain unresolved.
4. **Discovery priorities:** screener (#53/#85), watchlists/hotlists (#87), then Deep Backtesting (#118/#313, paid-account prerequisite). Alerts and paper trading are separate API families, not chart extensions.

## Issues

Current inventory: **95 open issues and 7 legacy open PRs** on 3 October 2026.
Rows describe capability disposition, not automatic authorization to close reports.

| Issue | Disposition | Evidence / next action |
| --- | --- | --- |
| [#321](https://github.com/Mathieu2301/TradingView-API/issues/321) getUser reports "Too many redirects" for HTTP 200 responses without auth_token | Partial → patched | Published since beta.2: starts at /chart/ and follows Location only on 3xx. HTTP regression and authenticated live suite pass; CAPTCHA/WAF remains outside this fix. |
| [#319](https://github.com/Mathieu2301/TradingView-API/issues/319) More Control and access to data | Missing | Paper-trading account management and order execution are not exposed by V4. |
| [#313](https://github.com/Mathieu2301/TradingView-API/issues/313) History Create Session / Request History Data Features help | Missing / gated | No HistorySession or request_history_data implementation. PR #204 is a protocol reference, not V4-compatible code; requires entitled-account live validation. |
| [#312](https://github.com/Mathieu2301/TradingView-API/issues/312) tradingview wss is updated? | Needs reproduction | Current transport and timeouts are implemented, but the original connection timeout has no host/network trace. Capture exact endpoint, Node version and error on V4. |
| [#311](https://github.com/Mathieu2301/TradingView-API/issues/311) Session for setMarket not changing CME group | Needs reproduction | session is encoded, but CME regular versus electronic-session semantics need a matching subscribed-account/browser comparison; encoding tests do not prove this. |
| [#308](https://github.com/Mathieu2301/TradingView-API/issues/308) Remove MR's | Administrative | Request to remove closed PRs is not a library defect. Do not delete contributor history as part of technical triage. |
| [#303](https://github.com/Mathieu2301/TradingView-API/issues/303) Implement "Use settlement as close" flag for Futures | Missing | No settlement-as-close option in chart resolution. Capture actual protocol key before implementing. |
| [#296](https://github.com/Mathieu2301/TradingView-API/issues/296) Analyst Forecast | Missing | No analyst-forecast API; technical ratings are not analyst price forecasts. |
| [#294](https://github.com/Mathieu2301/TradingView-API/issues/294) Can't init client with session and signature | Needs account reproduction | V4 credentials are { session, signature }; focused getUser patch helps page selection, but does not establish the original account entitlement or cookie validity. |
| [#293](https://github.com/Mathieu2301/TradingView-API/issues/293) Create feature drawing on chart | Missing / clarify | No API to create GUI drawings/Fibonacci objects. getDrawings reads saved data; study graphics are a different capability. |
| [#292](https://github.com/Mathieu2301/TradingView-API/issues/292) help in retrieving OHLCV data from the project: | Covered | README installation/quick start, docs/data-api.md and examples cover the requested entry point; package consumer smoke passes. |
| [#283](https://github.com/Mathieu2301/TradingView-API/issues/283) Alarms | Missing | No TradingView alert CRUD or triggered-alert subscription. Local quote/study listeners are not server-side alerts. |
| [#280](https://github.com/Mathieu2301/TradingView-API/issues/280) Stoch rsi k and D | Needs reproduction | getTechnicalAnalysis exposes summary ratings, not arbitrary scanner columns such as STOCH.RSI.D. Verify study output or design scanner API. |
| [#278](https://github.com/Mathieu2301/TradingView-API/issues/278) Login error: Please confirm that you are not a robot by clicking the captcha box | Upstream challenge | loginUser explicitly does not handle CAPTCHA/2FA. Document browser session cookies; do not report CAPTCHA as fixed. |
| [#277](https://github.com/Mathieu2301/TradingView-API/issues/277) load in indicators | Missing | No saved indicator-template/layout-to-studies loader. Reading drawings is not loading chart studies. |
| [#268](https://github.com/Mathieu2301/TradingView-API/issues/268) Issue with searchIndicator not returning results for some search terms. | Needs reproduction | Community search remains server-driven. Reproduce full-name versus short query with searchIndicators; do not infer exact-name matching from general search tests. |
| [#265](https://github.com/Mathieu2301/TradingView-API/issues/265) login ERROR in apis | Needs reproduction | CloudFront HTTP 400 is not proof of a parsing bug. Need sanitized request/status and response context on V4. |
| [#251](https://github.com/Mathieu2301/TradingView-API/issues/251) Table Cell Contents Unavailable | Needs private fixture | Graphics cells parser exists and is unit-tested, but original private-indicator table payload has not been replayed. |
| [#243](https://github.com/Mathieu2301/TradingView-API/issues/243) GetUser function error on notification count parsing | Covered | parseUserPage uses defensive pageNumber parsing; tests/unit/http.test.ts covers missing notification counts. |
| [#242](https://github.com/Mathieu2301/TradingView-API/issues/242) Real-time data of the exchange rate between Ethereum and the US dollar | Covered | getQuote/watchQuotes and getCandles expose exchange-qualified crypto pairs; choose the intended ETH/USD venue. See docs/data-api.md. |
| [#241](https://github.com/Mathieu2301/TradingView-API/issues/241) Support source as an input value type | Partial | Input values and multiple studies exist, but cross-study source dependencies (e.g. st4$4), lifecycle and ordering have no dedicated contract/test. |
| [#240](https://github.com/Mathieu2301/TradingView-API/issues/240) check study unexpected error | Usage / verify | STD;DEMA is a Pine identifier: use getIndicator, not BuiltInIndicator. Need authenticated DEMA-specific live reproduction before closing. |
| [#238](https://github.com/Mathieu2301/TradingView-API/issues/238) Getting adjusted price data  | Partial | adjustment is available and encoded; split/dividend parity against a specific browser chart is not proven. |
| [#237](https://github.com/Mathieu2301/TradingView-API/issues/237) Exporting / Receiving Timestamps to/from external application via WebSocket? | Missing | Library sessions do not remote-control an existing browser chart. Replay events are available only for library-owned sessions. |
| [#236](https://github.com/Mathieu2301/TradingView-API/issues/236) Connection Freezing After 30 Pings with No Error | Needs endurance proof | Heartbeat echo exists. Open PR #330 contains endurance tooling, but a general smoke does not reproduce OANDA:EURUSD HeikinAshi after 30 pings. |
| [#235](https://github.com/Mathieu2301/TradingView-API/issues/235) TypeScript Implementation | Covered | Native TypeScript sources and emitted declarations; strict consumer checked by scripts/smoke.mjs. |
| [#232](https://github.com/Mathieu2301/TradingView-API/issues/232) Crypto Cap (e.g. CRYPTOCAP:TOTAL) symbols return "invalid symbol" | Needs reproduction | Issue is specifically CRYPTOCAP Replay, not ordinary candles. Test replay on TOTAL/OTHERS with an entitled account. |
| [#231](https://github.com/Mathieu2301/TradingView-API/issues/231) Missing data in examples/FromToData.js - provided date and custom date | Partial / server limits | getCandles from/to pagination is implemented; historical intraday availability remains server/account limited. Reproduce original window, not just a recent range. |
| [#230](https://github.com/Mathieu2301/TradingView-API/issues/230) os.version is not a function / Can't resolve 'os" | Unsupported environment | V4 targets Node/Bun and imports node:os/ws. Browser-extension support is not established by removing the old os.version call. |
| [#225](https://github.com/Mathieu2301/TradingView-API/issues/225) Add additional filter on search market v3 | Missing → implemented | Published since beta.2: country/sector filters preserve exchange/type/offset. Deterministic forwarding checks and public endpoint probe. |
| [#224](https://github.com/Mathieu2301/TradingView-API/issues/224) Default setting indicators | Partial | getIndicator provides defaults and PineIndicator.clone preserves a baseline. No reset-to-defaults convenience method; document reload/clone workflow. |
| [#223](https://github.com/Mathieu2301/TradingView-API/issues/223) Premium account doesn't return 20000 bars for server='prodata' | Needs entitled account | Pagination and credentials exist, but Premium/prodata 20k-bar entitlement is not proven with Basic. |
| [#222](https://github.com/Mathieu2301/TradingView-API/issues/222) Wrong or expired sessionid/signature - all time | Needs account reproduction | V4 credentials are { session, signature }; focused getUser patch helps page selection, but does not establish the original account entitlement or cookie validity. |
| [#221](https://github.com/Mathieu2301/TradingView-API/issues/221) "Wrong or expired sessionid/signature" Consistently over and over again, tried fixes. | Needs account reproduction | V4 credentials are { session, signature }; focused getUser patch helps page selection, but does not establish the original account entitlement or cookie validity. |
| [#220](https://github.com/Mathieu2301/TradingView-API/issues/220) Retrieve chart pattern studies example missing | Needs entitled account | Chart patterns use native study IDs rather than Pine source retrieval. Need paid-pattern capture and example. |
| [#212](https://github.com/Mathieu2301/TradingView-API/issues/212) Unable to Access Invite Only Indicator: study_not_auth:Script@tv-scripting-507 undefined | Needs private asset | Private listing/auth paths are implemented; specific invite-only access and private study values require an authorized matching script fixture. |
| [#210](https://github.com/Mathieu2301/TradingView-API/issues/210) New Project: TradingView+NodeRed | Administrative | Collaboration/service proposal, not a reproducible library defect. No unsolicited outreach in this triage. |
| [#209](https://github.com/Mathieu2301/TradingView-API/issues/209) [FR] Pull a saved indicator template. | Missing | No saved indicator-template/layout-to-studies loader. Reading drawings is not loading chart studies. |
| [#207](https://github.com/Mathieu2301/TradingView-API/issues/207) Provide a backtest example | Covered | examples/strategy-report.js demonstrates trades and PnL; docs/v4-coverage.md records authenticated live evidence. Not Deep Backtesting. |
| [#202](https://github.com/Mathieu2301/TradingView-API/issues/202) `TradingView.loginUser` fails : 'Please confirm that you are not a robot by clicking the captcha box.' | Upstream challenge | loginUser explicitly does not handle CAPTCHA/2FA. Document browser session cookies; do not report CAPTCHA as fixed. |
| [#201](https://github.com/Mathieu2301/TradingView-API/issues/201) Private indicators | Needs private asset | Private listing/auth paths are implemented; specific invite-only access and private study values require an authorized matching script fixture. |
| [#199](https://github.com/Mathieu2301/TradingView-API/issues/199) Manage pine scripts | Missing | Pine permissions/listing are not script source create/update/delete APIs. |
| [#193](https://github.com/Mathieu2301/TradingView-API/issues/193) TypeError: str.replace is not a function - Handling Buffer Input in parseWSPacket | Covered by code | src/client/transport.ts converts Buffer, Buffer[] and ArrayBuffer to text before framing. Historical caller-specific environment not reproduced. |
| [#192](https://github.com/Mathieu2301/TradingView-API/issues/192) 15 minutes delay for MOEX market | Upstream entitlement / missing | Exchange real-time rights and server delays must be checked with that venue/account. getScreener is available since beta.3, but does not grant exchange real-time rights. |
| [#191](https://github.com/Mathieu2301/TradingView-API/issues/191) How to install? | Covered | README installation/quick start, docs/data-api.md and examples cover the requested entry point; package consumer smoke passes. |
| [#188](https://github.com/Mathieu2301/TradingView-API/issues/188) Pine 'referencing length of a series' error after about 12 hours | Needs long-run reproduction | 12-hour Pine max_bars_back failure is not a normal indicator input. Need script and long-running capture; short endurance runs cannot resolve it. |
| [#184](https://github.com/Mathieu2301/TradingView-API/issues/184) Proxy support  | Implemented | `createProxy(url \| agent)` returns a matching `fetch` and websocket `transport`; loopback CONNECT proxy tests cover HTTP, WS, HTTPS/WSS and auth failures on Node and Bun 1.3.6+. PR #208 cannot be merged unchanged. |
| [#182](https://github.com/Mathieu2301/TradingView-API/issues/182) Can't load indicator - (Study error: Study not allowed in this connection) | Upstream auth requirement | Authenticated Pine path is live-tested; anonymous study refusal is not eliminated. Recheck original script with credentials. |
| [#179](https://github.com/Mathieu2301/TradingView-API/issues/179) "Calculation timed out" error and account bans | Upstream limits | Server study/session/calculation limits are not removed by V4. Bound concurrency, release sessions and reproduce account-specific thresholds; no bulk retry flood. |
| [#174](https://github.com/Mathieu2301/TradingView-API/issues/174) How to use Supertrend? | Partial documentation | Indicator values/events and Pine discovery are documented. Supertrend transition semantics and plot selection deserve a focused example. |
| [#173](https://github.com/Mathieu2301/TradingView-API/issues/173) Max Sessions Rate Reached Error | Upstream limits | Server study/session/calculation limits are not removed by V4. Bound concurrency, release sessions and reproduce account-specific thresholds; no bulk retry flood. |
| [#172](https://github.com/Mathieu2301/TradingView-API/issues/172) Invite Only Indicators | Needs private asset | Private listing/auth paths are implemented; specific invite-only access and private study values require an authorized matching script fixture. |
| [#170](https://github.com/Mathieu2301/TradingView-API/issues/170) Can I generate alerts based on my PineScript Startegy? | Partial / missing | Study/strategy data can drive application callbacks; TradingView webhook-alert management is absent. |
| [#168](https://github.com/Mathieu2301/TradingView-API/issues/168) ECONN RESET | Needs reproduction | ECONNRESET is surfaced by transport; no transparent reconnect/resubscribe guarantee. Need original network trace. |
| [#167](https://github.com/Mathieu2301/TradingView-API/issues/167) Retrieve a picture of the custom chart. | Missing | No renderer/screenshot endpoint for library-owned chart sessions. |
| [#160](https://github.com/Mathieu2301/TradingView-API/issues/160) I need access to 1s timeframe of ETH/USDT (bianance) | Upstream entitlement | 1S accepted as a timeframe; seconds_not_entitled requires account rights, not a syntax fix. Ten-day history not proven. |
| [#159](https://github.com/Mathieu2301/TradingView-API/issues/159) new | Administrative | Collaboration/service proposal, not a reproducible library defect. No unsolicited outreach in this triage. |
| [#157](https://github.com/Mathieu2301/TradingView-API/issues/157) Replay mode works only on 1D or larger timeframes   | Needs timeframe proof | Daily Replay verified in beta.1; that does not establish intraday Replay on the reporter’s plan/window. |
| [#153](https://github.com/Mathieu2301/TradingView-API/issues/153) why i cant get my private indicators? | Needs private asset | Private listing/auth paths are implemented; specific invite-only access and private study values require an authorized matching script fixture. |
| [#147](https://github.com/Mathieu2301/TradingView-API/issues/147) How to get an year worth of data? | Partial / server limits | getCandles from/to pagination is implemented; historical intraday availability remains server/account limited. Reproduce original window, not just a recent range. |
| [#145](https://github.com/Mathieu2301/TradingView-API/issues/145) can't backtest using specific from to date even while using my tradingview premium session  | Missing / clarify | Chart candle date filtering is not a strategy calculation-date window. Deep Backtesting remains separate and unimplemented. |
| [#144](https://github.com/Mathieu2301/TradingView-API/issues/144) What does `rtc` field stand for on quotes? | Needs field documentation | Raw quote fields are passed through; verify rtc semantics with session-specific captures before promising extended-hours behavior. |
| [#138](https://github.com/Mathieu2301/TradingView-API/issues/138) Chart indicator study periods getting out of sync/corrupting themselves over time? | Needs long-run reproduction | Study-value merging exists; repainting versus index drift requires original script plus incremental/reloaded comparisons. |
| [#136](https://github.com/Mathieu2301/TradingView-API/issues/136) Alerts management | Missing | No TradingView alert CRUD or triggered-alert subscription. Local quote/study listeners are not server-side alerts. |
| [#135](https://github.com/Mathieu2301/TradingView-API/issues/135) Not sure how to install, index.js also missing | Covered | README installation/quick start, docs/data-api.md and examples cover the requested entry point; package consumer smoke passes. |
| [#134](https://github.com/Mathieu2301/TradingView-API/issues/134) Future data | Needs reproduction | Futures symbols supported generically, but original venue/contract and permission details are missing. Do not infer ES/CL success from crypto. |
| [#133](https://github.com/Mathieu2301/TradingView-API/issues/133) No ask and bid after subscribing for quotes | Upstream data / verify | Bid/ask fields may be requested, but upstream availability for TSE:2801 is not guaranteed. Capture quote payload and update mode. |
| [#132](https://github.com/Mathieu2301/TradingView-API/issues/132) Replaying old time with both "replay" and "to" set seems to repeat same time | Needs targeted regression | Replay and to each exist; their combination is not proven by separate tests. Reproduce repeated-candle scenario. |
| [#128](https://github.com/Mathieu2301/TradingView-API/issues/128) How would I get the values from a indicator ?  | Partial documentation | Indicator values/events and Pine discovery are documented. Supertrend transition semantics and plot selection deserve a focused example. |
| [#125](https://github.com/Mathieu2301/TradingView-API/issues/125) Technicals are being handled differently | Usage / partial | Native volume-profile IDs use BuiltInIndicator, not getIndicator/Pine facade. Fixed profile is live-tested; session-profile variant needs its own proof. |
| [#124](https://github.com/Mathieu2301/TradingView-API/issues/124) How do I reconnect to client after my internet reconnects? | Missing | Client is terminal after close. Recreate client and subscriptions; automatic reconnect/backoff/resubscribe is not implemented. |
| [#120](https://github.com/Mathieu2301/TradingView-API/issues/120) Bug function searchMarket | Covered | searchMarkets splits EXCHANGE:SYMBOL and uses v3 endpoint; tests/unit/http.test.ts asserts exchange and query encoding. |
| [#119](https://github.com/Mathieu2301/TradingView-API/issues/119) ENOTFOUND event not being handled | Covered by code | wsTransport registers socket error handler; client emits typed errors. Add native DNS-failure regression before treating every network failure as resolved. |
| [#118](https://github.com/Mathieu2301/TradingView-API/issues/118) Deep Backtesting | Missing / gated | No HistorySession or request_history_data implementation. PR #204 is a protocol reference, not V4-compatible code; requires entitled-account live validation. |
| [#117](https://github.com/Mathieu2301/TradingView-API/issues/117) How to use TradingView-API? | Covered / plan limits | README, low-level docs and Replay example provide setup. Intraday availability still requires separate account/timeframe verification. |
| [#115](https://github.com/Mathieu2301/TradingView-API/issues/115) how to use FromToData.js?  | Partial / server limits | getCandles from/to pagination is implemented; historical intraday availability remains server/account limited. Reproduce original window, not just a recent range. |
| [#112](https://github.com/Mathieu2301/TradingView-API/issues/112) Get 1min candle data exposed as API | Partial | Minute OHLCV retrieval exists; OI availability, external-feed import and GUI rendering are separate unsupported requirements. |
| [#111](https://github.com/Mathieu2301/TradingView-API/issues/111) Tradingview login error | Covered documentation | README/authentication docs explain credentials and login limitations; do not reuse a username/password as a session cookie. |
| [#110](https://github.com/Mathieu2301/TradingView-API/issues/110) How can i use Fibonacci Retracement | Missing / clarify | No API to create GUI drawings/Fibonacci objects. getDrawings reads saved data; study graphics are a different capability. |
| [#108](https://github.com/Mathieu2301/TradingView-API/issues/108) Error on example CustomTimeframe | Upstream entitlement | 1S accepted as a timeframe; seconds_not_entitled requires account rights, not a syntax fix. Ten-day history not proven. |
| [#105](https://github.com/Mathieu2301/TradingView-API/issues/105) How to run this app | Covered | README installation/quick start, docs/data-api.md and examples cover the requested entry point; package consumer smoke passes. |
| [#101](https://github.com/Mathieu2301/TradingView-API/issues/101) FakeReplay always returning the same day | Needs targeted regression | Negative-count history is live-tested generally; exact repeated-day/gap cases and exchange holidays still need reproduction. |
| [#89](https://github.com/Mathieu2301/TradingView-API/issues/89) No "strategyReport.trades"  data for private strategy  backtest | Needs private asset | Public and compressed reports are proven; missing trades for the specific private strategy is not yet reproduced. |
| [#88](https://github.com/Mathieu2301/TradingView-API/issues/88) Data point is missing in FakeReplayMode example output | Needs targeted regression | Negative-count history is live-tested generally; exact repeated-day/gap cases and exchange holidays still need reproduction. |
| [#87](https://github.com/Mathieu2301/TradingView-API/issues/87) Feature : get watchlists | Covered with live limits | Published in beta.4: getWatchlists and scanner-ranked getHotlist. Populated lists are fixture-tested; available account lists are empty. UI parity is not claimed. |
| [#85](https://github.com/Mathieu2301/TradingView-API/issues/85) Question : Can you enable stock screener real-time ? | Upstream entitlement / missing | Exchange real-time rights and server delays must be checked with that venue/account. getScreener is available since beta.3, but does not grant exchange real-time rights. |
| [#84](https://github.com/Mathieu2301/TradingView-API/issues/84) Alerts feature | Missing | No TradingView alert CRUD or triggered-alert subscription. Local quote/study listeners are not server-side alerts. |
| [#83](https://github.com/Mathieu2301/TradingView-API/issues/83) how to get update data of strategy.entry trigger signal. | Partial | Strategy reports and study updates exist; no dedicated exactly-once strategy.entry signal stream. Application must distinguish intrabar updates. |
| [#80](https://github.com/Mathieu2301/TradingView-API/issues/80) [V3] Same output multiple times | Needs reproduction | Repeated update events may be intrabar updates or study lifecycle effects. No evidence yet of a V4 fix for this exact script. |
| [#79](https://github.com/Mathieu2301/TradingView-API/issues/79) Where can I find the chart_id for getDrawings? | Partial documentation | getDrawings supports chartId/layout inputs, but extracting the correct internal chart ID needs a saved-layout example and private validation. |
| [#73](https://github.com/Mathieu2301/TradingView-API/issues/73) Strategy Optimization Steps | Partial | Inputs and reports exist; no bounded optimization runner, date-window Deep Backtest or throttle-aware multithreading API. |
| [#66](https://github.com/Mathieu2301/TradingView-API/issues/66) Maximum number of studies per chart has been reached | Upstream limits | Server study/session/calculation limits are not removed by V4. Bound concurrency, release sessions and reproduce account-specific thresholds; no bulk retry flood. |
| [#53](https://github.com/Mathieu2301/TradingView-API/issues/53) Stock Screener API | Covered HTTP API | Published in beta.3: getScreener supports columns, filters, ranking and pagination; deterministic and anonymous live checks. Not a push subscription. |
| [#51](https://github.com/Mathieu2301/TradingView-API/issues/51) Adding some sort of documentation | Covered | README installation/quick start, docs/data-api.md and examples cover the requested entry point; package consumer smoke passes. |
| [#30](https://github.com/Mathieu2301/TradingView-API/issues/30) Can I Hire You To Set This Up For Me? | Administrative | Collaboration/service proposal, not a reproducible library defect. No unsolicited outreach in this triage. |
| [#24](https://github.com/Mathieu2301/TradingView-API/issues/24) Renko chart's indicator value does not match GUI-based TradingView's, given same configurations | Needs parity reproduction | Renko chart type is live-tested, but this exact multi-timeframe study/GUI value mismatch is not. Need matched bars, inputs and account. |

## Legacy pull requests

| PR | Verified disposition | Next action |
| --- | --- | --- |
| [#330](https://github.com/Mathieu2301/TradingView-API/pull/330) | Closed/superseded after focused ports in #334/#335. Authentication, parity/endurance tooling and recovery checks are included in beta.2. | No remaining code port from this PR is needed for the documented scope; the recovered two-hour result is in reliability evidence. |
| [#322](https://github.com/Mathieu2301/TradingView-API/pull/322) | Legacy V3 authentication patch; not directly applicable to TS V4. | Its chart-page/status semantics are carried through #330 into this port. Decide V3 backport separately while latest is 3.5.2. |
| [#320](https://github.com/Mathieu2301/TradingView-API/pull/320) | V3 this-binding patch. V4 HTTP functions are standalone, not receiver-based. | Superseded for V4; possible V3 maintenance value. |
| [#318](https://github.com/Mathieu2301/TradingView-API/pull/318) | V4 uses standalone HTTP functions and patched Vitest 4.1.11. The original Vitest 3 baseline no longer applies. | Audit confirmed GHSA-82fw-gwwq-j7x9 in Vitest/mocker. Updated to patched Vitest 4.1.11+ in this change; not the older vulnerable 4.1.9 from the PR. |
| [#289](https://github.com/Mathieu2301/TradingView-API/pull/289) | General chart event registration exists via Emitter.on/onAny and event tests. | Superseded for V4; no need to port V3 callback storage. |
| [#219](https://github.com/Mathieu2301/TradingView-API/pull/219) | Native TS build emits declarations and package smoke compiles a strict consumer. | Superseded for V4; avoid stale generated V3 declarations. |
| [#208](https://github.com/Mathieu2301/TradingView-API/pull/208) | Axios/ws proxy patch targets removed V3 architecture. V4 offers transport/fetch injection, not a turnkey proxy. | Intent preserved by `createProxy` (no global `SetAgent`, no new dependency; SOCKS via a caller-supplied agent on Node). |
| [#204](https://github.com/Mathieu2301/TradingView-API/pull/204) | Distinct history-data/HistorySession protocol absent in V4. Author’s historical Premium run is not current verification. | Port only after current capture/entitlement proof; share report decoding and add failure/cleanup tests. |

## Verification for this change

- `npm run check`: typecheck, lint, 118 deterministic tests, build, Node/Bun packed-package smoke and strict TypeScript consumer.
- `npm run test:bun`: independent Bun unit run.
- Country/sector live probe is anonymous; filter forwarding is deterministic-tested. Search results do not constitute a full sector-classification audit.
- Dependency audit: baseline had two moderate entries for the same Vitest/mocker advisory; patched development dependency in this change.
- No new authenticated, private-script, Premium or long-duration claims are made.
- No npm publication or promotion of the `latest` tag is part of this change.

## Screener follow-up

Beta.3 adds `getScreener` for #53 and scanner fields relevant to #280. See
[screener documentation](screener.md). #85 real-time exchange entitlement is not
resolved by a successful HTTP scan. Watchlists shipped subsequently in beta.4; paid/private case limitations remain.

## Watchlist follow-up

Beta.4 adds read-only `getWatchlists` and scanner-ranked `getHotlist` (#87).
Authenticated discovery returned two empty lists; populated entries are fixture-tested.
Exact TradingView UI hotlist parity is not claimed. See [watchlists](watchlists.md).

## Account and endurance follow-up

Beta.5 ships opt-in account/endurance diagnostics and documents six successful
private USER-script runs. Deep Backtesting reached the server but returned
`request_error` / `not_allowed` with the available account. This is a concrete
prerequisite blocker, not implemented Premium support. Original private-script,
CME/GUI and 12-hour issue fixtures remain necessary; no historical issue is closed
from the broader smoke results. See [reliability evidence](v4-reliability.md).
