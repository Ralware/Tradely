import { describe, expect, it } from 'vitest';
import * as root from '../../src/index.js';
import * as data from '../../src/data/index.js';
import * as backtest from '../../src/backtest/index.js';

describe('public API', () => {
  it('root entry exposes the high-level, low-level and HTTP APIs', () => {
    expect(Object.keys(root).sort()).toEqual([
      'ALL_QUOTE_FIELDS', 'BuiltInIndicator', 'CHART_TYPE_STUDIES', 'ChartSession', 'DEFAULT_TIMEOUT_MS', 'Emitter',
      'PineIndicator', 'PinePermissionManager', 'QuoteSession', 'QuoteSubscription', 'Study', 'TradingViewClient',
      'TradingViewError', 'TradingViewProvider', 'applyGraphicsCommands', 'clearIndicatorCache', 'createProxy', 'createWsTransport', 'getCandles', 'getChartToken', 'getDrawings', 'getHotlist',
      'getIndicator', 'getIndicatorData', 'getPrivateIndicators', 'getQuote', 'getQuotes', 'getScreener', 'getSymbolInfo',
      'getTechnicalAnalysis', 'getUser', 'getWatchlists', 'loginUser', 'mergeStrategyReport', 'parseGraphics', 'parseIndicatorDefinition',
      'parseTrades', 'protocol', 'quoteSymbolKey', 'resolveQuoteFields', 'searchIndicators', 'searchMarkets', 'summarizeStrategyReport',
      'timeframeSeconds', 'toTradingViewError', 'watchCandles', 'watchIndicator', 'watchQuotes', 'wsTransport',
    ]);
    expect(Object.keys(root.protocol).sort()).toEqual([
      'createSessionId', 'decodeCompressed', 'decodeFrames', 'encodeFrame', 'encodeHeartbeat', 'encodePacket',
      'normaliseBase64', 'readFirstZipEntry',
    ]);
  });

  it('data entry only exposes the simplified data API', () => {
    expect(Object.keys(data).sort()).toEqual([
      'DEFAULT_TIMEOUT_MS', 'TradingViewError', 'TradingViewProvider', 'getCandles', 'getHotlist', 'getIndicatorData', 'getQuote', 'getQuotes', 'getScreener', 'getSymbolInfo',
      'getTechnicalAnalysis', 'getWatchlists', 'searchIndicators', 'searchMarkets', 'summarizeStrategyReport', 'watchCandles', 'watchIndicator', 'watchQuotes',
    ]);
    expect(data.getCandles).toBe(root.getCandles);
  });

  it('backtest entry exposes the protocol, its building blocks and the report helpers', () => {
    expect(Object.keys(backtest).sort()).toEqual([
      'BACKTEST_DEFAULTS', 'TradingViewError', 'atr', 'atrExit', 'atrTrailingExit', 'backtest', 'backtestMany', 'chartData', 'checkCausality', 'computeMetrics',
      'createRng', 'defaultExits', 'deriveSeed', 'ema', 'fetchSnapshot', 'fillPrice', 'findPivots', 'fixedExit', 'formatReport',
      'formatTable', 'formatWarning', 'freezeSnapshot', 'isoTime', 'loadSnapshot', 'percentileRank', 'quantile', 'randomBaseline', 'resolveWarmupBars',
      'rsi', 'rsiDivergence', 'runBacktest', 'simulate', 'sma', 'snapshotInfo', 'splitSegments', 'tradeReturn', 'tradesToCsv',
    ]);
    expect(backtest.TradingViewError).toBe(root.TradingViewError);
  });
});
